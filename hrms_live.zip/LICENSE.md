# Commercial License

Copyright (c) 2019 - present [AppSeed](http://appseed.us/) / [Creative-Tim](https://www.creative-tim.com/)

<br />

## Licensing Information

Licensed under [Creative Tim EULA](https://www.creative-tim.com/license)

---
For more information regarding licensing, please access the [knowledge center](https://www.creative-tim.com/knowledge-center/licenses/).  
