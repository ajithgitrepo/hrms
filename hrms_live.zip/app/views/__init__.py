
from .dashborad_view import *
from .leave_request_view import *
from .employee_view import *
from .role_view import *
from .department_view import *
from .leave_type_view import *
from .leave_balance_view import *
from .onboard_employee_view import *
from .attendance_view import *
from .organization_files_view import *
from .employee_files_view import *
from .new_hires_view import *
from .announcements_view import *
from .restriction_view import *
from .calendar_details_view import *

from .exit_deatails_view import *
from .asset_deatails_view import *
from .holiday_details_view import *
from .travel_request_view import *
from .travel_expense_view import *
from .compensatory_request_view import *
from .heirarchy_view import *

from .location_view import *
from .task_view import *
from .weekend_view import *
from .self_service_view import *




